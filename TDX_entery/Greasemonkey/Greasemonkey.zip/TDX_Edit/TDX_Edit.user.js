// ==UserScript==
// @name     TDX_Edit
// @version  2
// @grant    none
// ==/UserScript==
var toST = 0;

window.addEventListener("load", (event) => {
  const per = new URLSearchParams(window.location.search);
  if(document.getElementById("attribute502")){
    if(!document.getElementById("attribute502").value)
        document.getElementById("attribute502").value = per.get('id');
    if(!document.getElementById("attribute503").value)	
        document.getElementById("attribute503").value = per.get('id');
    if(!document.getElementById("attribute1390").value)
        document.getElementById("attribute1390").value = per.get('id');
  }
});


document.addEventListener("keydown", (event) => {
    console.log("Edit: " + event.which);

    if(event.which == "112" || event.which == "113"){ //F1 & F2
        event.preventDefault();

        document.getElementById("attribute2697").value = "";
        document.getElementById("select2-chosen-4").innerHTML = "Good use!";

        document.getElementById("attribute514").value = "";
        document.getElementById("select2-chosen-1").innerHTML = "Joan Gabel";

        //document.getElementById("s2id_autogen3").value = "965";
        //document.getElementById("select2-chosen-3").innerHTML = "FM Waste Services (10293)";

        document.getElementById("attribute507").value = "63";
        document.getElementById("select2-chosen-8").innerHTML = "AHCWARE";

        document.getElementById("attribute508").value = "";
        document.getElementById("select2-chosen-9").innerHTML = "There is no room.";

        document.getElementById("attribute2705").value = "4524";
        document.getElementById("select2-chosen-6").innerHTML = "In Stock";

        if(event.which == "112"){
            document.getElementById("attribute2706").value = "5210";
            document.getElementById("select2-chosen-7").innerHTML = "Pending repair";
            document.title = "Pending repair";
        }
        if(event.which == "113"){
            document.getElementById("attribute2706").value = "5207";
            document.getElementById("select2-chosen-7").innerHTML = "Pending disposal";
            document.title = "Pending disposal";
        }
    }

    if(event.which == "114"){ //F3
        event.preventDefault();
        const dat = new Date();
        todays_date = dat.toString();
        if (document.getElementById("attribute2686").value !== "")
        document.getElementById("attribute2686").value += "\n\n";
        document.getElementById("attribute2686").value += "----\n" + todays_date + "\nReceived by ReUse.\nHDD N/A\n----";
        document.getElementById("attribute2686").scrollIntoView(true);
        window.scrollBy(0, -100);
    }
    
    if(event.which == "115"){ //F4
        event.preventDefault();
        const dat = new Date();
        todays_date = dat.toString();
        if (document.getElementById("attribute2686").value !== "")
        document.getElementById("attribute2686").value += "\n\n";
        document.getElementById("attribute2686").value += "----\n" + todays_date + "\nReceived by ReUse.\nHDD SN: ----";
        pos = document.getElementById("attribute2686").value.length-4;
        document.getElementById("attribute2686").focus();
        document.getElementById("attribute2686").setSelectionRange(pos, pos);
        document.getElementById("attribute2686").scrollIntoView(true);
        window.scrollBy(0, -100);
    }
    
    if(event.which == "116"){ //F5
        event.preventDefault();
        document.getElementById("attribute502").focus();
        document.getElementById("attribute502").scrollIntoView(true);
        window.scrollBy(0, -100);
    }
    
    if(event.which == "117"){ //F6
        event.preventDefault();
        document.getElementById("attribute1390").focus();
        document.getElementById("attribute1390").scrollIntoView(true);
        window.scrollBy(0, -100);
        toST = 1;
    }
    
    if(event.which == "9"){ //Tab
        if (toST){
        event.preventDefault();
        document.getElementById("attribute503").focus();
        document.getElementById("attribute503").scrollIntoView(true);
        window.scrollBy(0, -100);
        toST = 0;
        }
    }
    
    if(event.which == "27"){ //Esc
        event.preventDefault();
        if(document.getElementById("btnEdit"))
            document.getElementById("btnEdit").click();
        
        if(document.getElementById("btnSubmit")){
            sn = document.getElementById("attribute502").value;
            if(!document.getElementById("attribute503").value)
                document.getElementById("attribute503").value = sn;
            if(!document.getElementById("attribute1390").value)
                document.getElementById("attribute1390").value = sn;
        document.getElementById("btnSubmit").click();
        }
    }

    if(event.which == "13"){ //Enter
        if(document.activeElement == document.getElementById("attribute502")||
        document.activeElement == document.getElementById("attribute503")||
        document.activeElement == document.getElementById("attribute1390")) {
        event.preventDefault();
            sn = document.getElementById("attribute502").value;
            if(!document.getElementById("attribute503").value)
                document.getElementById("attribute503").value = sn;
            if(!document.getElementById("attribute1390").value)
                document.getElementById("attribute1390").value = sn;
        document.getElementById("btnSubmit").click();
        }
    }
                                    
    if(event.which == "123" ){ //F12
        event.preventDefault();
        
        document.title = "Sold Asset";
        
        if(document.getElementById("btnEdit"))
            document.getElementById("btnEdit").click();
        
        //await new Promice(r => setTimeout(r, 2000));
        
        document.getElementById("attribute2705").value = "4527";
        document.getElementById("select2-chosen-1").innerHTML = "Retired";
        
        document.getElementById("attribute2706").value = "4542";
        document.getElementById("select2-chosen-2").innerHTML = "Sold";
        
        sn = document.getElementById("attribute502").value;
        if(!document.getElementById("attribute503").value)
            document.getElementById("attribute503").value = sn;
        if(!document.getElementById("attribute1390").value)
            document.getElementById("attribute1390").value = sn;
        
        if(document.getElementById("btnSubmit"))
            document.getElementById("btnSubmit").click();
    }
});

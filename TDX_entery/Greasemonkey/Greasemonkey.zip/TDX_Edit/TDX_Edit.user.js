// ==UserScript==
// @name     TDX_Edit
// @version  1
// @grant    none
// ==/UserScript==

var toST = 0;

document.addEventListener("keydown", (event) => {
  console.log("Edit: " + event.which);
  
  if(event.which == "112" || event.which == "113"){ //F1 & F2
    event.preventDefault();
    document.getElementById("attribute2705").value = "4524";
    document.getElementById("select2-chosen-1").innerHTML = "In Stock";
    
    if(event.which == "112"){
    	document.getElementById("attribute2706").value = "5210";
    	document.getElementById("select2-chosen-2").innerHTML = "Pending repair";
    }
    if(event.which == "113"){
    	document.getElementById("attribute2706").value = "5207";
    	document.getElementById("select2-chosen-2").innerHTML = "Pending disposal";
    }
    
    document.getElementById("attribute2697").value = "";
    document.getElementById("select2-chosen-3").innerHTML = "Good use!";
    
    document.getElementById("attribute514").value = "";
    document.getElementById("select2-chosen-4").innerHTML = "Joan Gabel";
    
    document.getElementById("attribute515").value = "965";
    document.getElementById("select2-chosen-5").innerHTML = "FM Waste Services (10293)";
    
    document.getElementById("attribute507").value = "63";
    document.getElementById("select2-chosen-6").innerHTML = "AHCWARE";
    
    document.getElementById("attribute508").value = "";
    document.getElementById("select2-chosen-7").innerHTML = "There is no room.";
  }
  
  if(event.which == "114"){ //F3
    event.preventDefault();
    const dat = new Date();
    todays_date = dat.toString();
    if (document.getElementById("attribute2686").value !== "")
      document.getElementById("attribute2686").value += "\n\n";
    document.getElementById("attribute2686").value += "----\n" + todays_date + "\nReceived by ReUse.\nHDD N/A\n----";
    document.getElementById("attribute2686").scrollIntoView(true);
    window.scrollBy(0, -100);
  }
  
  if(event.which == "115"){ //F4
    event.preventDefault();
    const dat = new Date();
    todays_date = dat.toString();
    if (document.getElementById("attribute2686").value !== "")
      document.getElementById("attribute2686").value += "\n\n";
    document.getElementById("attribute2686").value += "----\n" + todays_date + "\nReceived by ReUse.\nHDD SN: ----";
    pos = document.getElementById("attribute2686").value.length-4;
    document.getElementById("attribute2686").focus();
    document.getElementById("attribute2686").setSelectionRange(pos, pos);
    document.getElementById("attribute2686").scrollIntoView(true);
    window.scrollBy(0, -100);
  }
  
  if(event.which == "116"){ //F5
    event.preventDefault();
    document.getElementById("attribute502").focus();
    document.getElementById("attribute502").scrollIntoView(true);
    window.scrollBy(0, -100);
  }
  
  if(event.which == "117"){ //F6
    event.preventDefault();
    document.getElementById("attribute1390").focus();
    document.getElementById("attribute1390").scrollIntoView(true);
    window.scrollBy(0, -100);
    toST = 1;
  }
  
  if(event.which == "9"){ //Tab
    if (toST){
      event.preventDefault();
      document.getElementById("attribute503").focus();
      document.getElementById("attribute503").scrollIntoView(true);
      window.scrollBy(0, -100);
      toST = 0;
    }
  }
  
  if(event.which == "123"){ //F12
    event.preventDefault();
    document.getElementById("btnSubmit").click();

  }
});
